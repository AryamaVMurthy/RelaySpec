"""Capture native proposal states and prefix-valid target verification labels."""
import argparse
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import torch
from transformers import AutoModelForCausalLM

from run_lane import TARGET, DRAFT, COMMIT, sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text())
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    if torch.cuda.device_count() != 1:
        raise RuntimeError("One GPU per collection lane")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    source = os.environ["DFLASH_SOURCE"]
    if subprocess.check_output(["git", "-C", source, "rev-parse", "HEAD"], text=True).strip() != COMMIT:
        raise RuntimeError("Source revision mismatch")
    subprocess.run(["git", "-C", source, "diff", "--exit-code", "HEAD", "--", "dflash/model.py"], check=True, capture_output=True)
    sys.path.insert(0, source)
    official = importlib.import_module("dflash.model")
    load = dict(cache_dir=os.environ["HF_HUB_CACHE"], local_files_only=True, dtype=torch.bfloat16, attn_implementation="sdpa")
    target = AutoModelForCausalLM.from_pretrained(TARGET["id"], revision=TARGET["revision"], **load).cuda().eval().requires_grad_(False)
    native = official.DFlashDraftModel.from_pretrained(DRAFT["id"], revision=DRAFT["revision"], **load).cuda().eval().requires_grad_(False)
    eos = target.generation_config.eos_token_id
    eos = [eos] if isinstance(eos, int) else eos
    prepared = json.loads(Path(cfg["prepared_index"]).read_text())
    if prepared["target"] != TARGET or prepared["status"] != "pass":
        raise RuntimeError("Prepared prompts do not match target")
    scratch = Path(os.environ["NATIVE_SCRATCH"])/os.environ["SLURM_JOB_ID"]/args.output.name
    scratch.mkdir(parents=True, exist_ok=False)
    state = {}
    def draft_hook(module, inputs, output):
        state["hidden"] = output[0, 1:].detach().cpu()
    def target_hook(module, inputs, kwargs, output):
        if "hidden" not in state:
            return
        proposal = (inputs[0] if inputs else kwargs["input_ids"])[0, 1:]
        labels = output.logits[0, :-1].argmax(-1)
        if len(proposal) != 15 or len(labels) != 15:
            raise RuntimeError("Unexpected native verification block shape")
        matches = proposal == labels
        valid = torch.cat([torch.ones(1, device=labels.device, dtype=torch.bool), matches.cumprod(0)[:-1].bool()])
        state["blocks"].append({"hidden": state.pop("hidden"), "labels": labels.cpu(), "valid": valid.cpu(), "native_tokens": proposal.cpu(), "question_sha": state["question_sha"]})
    handles = [native.register_forward_hook(draft_hook), target.register_forward_hook(target_hook, with_kwargs=True)]
    outputs, used = [], set()
    try:
        for split, count in [("train", cfg["train_records"]), ("validation", cfg["val_records"])]:
            selected = [entry for i, entry in enumerate(sorted([e for e in prepared["entries"] if e["split"] == split], key=lambda e: e["index"])) if i%cfg["shards"] == cfg["shard"]][:count]
            if len(selected) != count:
                raise RuntimeError("Not enough disjoint source prompts")
            state["blocks"] = []
            records = []
            for entry in selected:
                if entry["question_sha"] in used or sha(entry["path"]) != entry["sha256"]:
                    raise RuntimeError("Duplicate prompt or changed source cache")
                used.add(entry["question_sha"])
                payload = torch.load(entry["path"], map_location="cpu", weights_only=True)
                ids = payload["input_ids"][:payload["anchor_min"]].unsqueeze(0).cuda()
                state["question_sha"] = entry["question_sha"]
                before = len(state["blocks"])
                generated = official.dflash_generate(native, target, ids, cfg["output_cap"], eos, 0., block_size=16, return_stats=True)
                if len(state["blocks"])-before != len(generated.acceptance_lengths):
                    raise RuntimeError("Proposal/verification capture counts differ")
                for block, accepted in zip(state["blocks"][before:], generated.acceptance_lengths):
                    if int(block["valid"].sum()) != min(accepted, 15):
                        raise RuntimeError("Prefix labels extend beyond first rejection")
                records.append({"question_sha": entry["question_sha"], "input_tokens": ids.shape[1], "output_tokens": generated.num_output_tokens, "blocks": len(state["blocks"])-before})
            blocks = state["blocks"]
            path = scratch/f"{split}.pt"
            torch.save({"hidden": torch.stack([b["hidden"] for b in blocks]), "labels": torch.stack([b["labels"] for b in blocks]), "valid": torch.stack([b["valid"] for b in blocks]), "native_tokens": torch.stack([b["native_tokens"] for b in blocks]), "question_shas": [b["question_sha"] for b in blocks]}, path)
            outputs.append({"split": split, "path": str(path), "sha256": sha(path), "records": records, "blocks": len(blocks), "supervised_positions": sum(int(b["valid"].sum()) for b in blocks)})
            print(json.dumps({"event": "captured", "split": split, "blocks": len(blocks), "elapsed": time.perf_counter()-started}), flush=True)
    finally:
        for handle in handles:
            handle.remove()
    result = {"status": "pass", "config": cfg, "target": TARGET, "draft": DRAFT, "source_commit": COMMIT, "prepared_sha256": sha(cfg["prepared_index"]), "outputs": outputs, "elapsed_seconds": time.perf_counter()-started, "scope": "Native greedy rollouts from disjoint Numina training/validation prompts. Only actual accepted-prefix labels and the first rejection are supervised; hypothetical post-rejection target labels are masked. Generated features past the requested cap can occur in the last verification block and are retained only when prefix-valid."}
    (args.output/"progress-data.json").write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
