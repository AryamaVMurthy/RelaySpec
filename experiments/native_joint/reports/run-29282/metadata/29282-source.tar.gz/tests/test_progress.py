import torch

from core import ProgressHead, progress_loss, stop_aware_prefix_mask


def test_progress_head_starts_as_exact_identity():
    hidden = torch.randn(2, 15, 8)
    head = ProgressHead(8, 2)
    assert torch.equal(hidden, head(hidden))


def test_invalid_post_rejection_labels_have_zero_gradient():
    logits = torch.randn(1, 5, 7, requires_grad=True)
    labels = torch.tensor([[1, 2, 3, 4, 5]])
    native = torch.tensor([[1, 2, 0, 0, 0]])
    valid = torch.tensor([[True, True, True, False, False]])
    loss, metrics = progress_loss(logits, labels, valid, native, error_weight=4.)
    loss.backward()
    assert logits.grad[:, :3].abs().sum() > 0
    assert logits.grad[:, 3:].abs().sum() == 0
    assert metrics["first_errors"] == 1
    changed = labels.clone()
    changed[:, 3:] = 0
    other, _ = progress_loss(logits.detach(), changed, valid, native, error_weight=4.)
    assert torch.equal(loss.detach(), other)


def test_position_specific_correction_preserves_other_positions_exactly():
    hidden = torch.ones(2, 15, 8)
    head = ProgressHead(8, 2, positions=[0])
    with torch.no_grad():
        head.up.weight.fill_(1)
        head.down.weight.fill_(1)
    output = head(hidden)
    assert torch.equal(output[:, 1:], hidden[:, 1:])
    assert not torch.equal(output[:, 0], hidden[:, 0])


def test_margin_preservation_loss_detaches_teacher_and_masks_future():
    student = torch.randn(1, 5, 7, requires_grad=True)
    teacher = torch.randn_like(student, requires_grad=True)
    labels = torch.tensor([[1, 2, 3, 4, 5]])
    native = torch.tensor([[1, 2, 0, 0, 0]])
    valid = torch.tensor([[True, True, True, False, False]])
    loss, _ = progress_loss(student, labels, valid, native, kind="margin_kl", native_logits=teacher)
    loss.backward()
    assert teacher.grad is None
    assert student.grad[:, 3:].abs().sum() == 0


def test_eos_label_is_kept_but_later_positions_are_masked():
    native = torch.tensor([[1, 99, 2, 3], [1, 2, 3, 4]])
    valid = torch.ones_like(native, dtype=torch.bool)
    assert stop_aware_prefix_mask(valid, native, [99]).tolist() == [[True, True, False, False], [True, True, True, True]]


def test_soft_progress_rewards_extending_prefix_and_masks_unverified_tail():
    logits = torch.tensor([[[5., 0.], [0., 1.], [1., 0.]]], requires_grad=True)
    labels = torch.zeros(1, 3, dtype=torch.long)
    valid = torch.tensor([[True, True, False]])
    native = torch.tensor([[0, 1, 0]])
    loss, _ = progress_loss(logits, labels, valid, native, kind="soft_progress")
    loss.backward()
    assert logits.grad[:, 2].abs().sum() == 0
    corrected = logits.detach().clone()
    corrected[:, 1, 0] = 3.
    better, _ = progress_loss(corrected, labels, valid, native, kind="soft_progress")
    assert better < loss.detach()


def test_warm_hints_preserve_known_token_and_unused_masks():
    from radical_decode import warm_start_noise
    embedding = torch.nn.Embedding(10, 4)
    noise = embedding(torch.tensor([[2, 9, 9, 9, 9]]))
    assert torch.equal(warm_start_noise(noise, embedding, [3, 4], 0.), noise)
    blended = warm_start_noise(noise, embedding, [3, 4], .25)
    assert torch.equal(blended[:, :1], noise[:, :1])
    assert torch.equal(blended[:, 3:], noise[:, 3:])
    assert torch.allclose(blended[:, 1:3], .75*noise[:, 1:3]+.25*embedding(torch.tensor([[3, 4]])))
